package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class BscThird2Activity extends AppCompatActivity {


    private AdView mAdView;
    WebView myWebViewBsc3YearNotes;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bsc_third2);


        myWebViewBsc3YearNotes = (WebView) findViewById(R.id.myWebViewBsc3YearNotes);
        myWebViewBsc3YearNotes.setWebViewClient(new WebViewClient());
        WebSettings webSettings = myWebViewBsc3YearNotes.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mAdView = findViewById(R.id.adView3year2);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        int paper_position=getIntent().getIntExtra("bsc3yearnotespdf",0);

        if (paper_position==0) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/11i6YV_1u8YnYsdnJhRDs8L873u1-1GdC/view?usp=sharing   ");
        }

        else if (paper_position==1) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/11kkZ6yVTe5p2Lz82mHfLSc-yu-8oKG6J/view?usp=sharing  ");
        }

        else if (paper_position==2) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/1EqAqWyDexEwbUW_PJmVL_0M5gpGi_4ym/view?usp=sharing  ");
        }

        else if (paper_position==3) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/14uqdd97De3tjw0kkedVCPLggEPlsFpjV/view?usp=sharing  ");
        }

        else if (paper_position==4) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/17vRI8pUOg9VbUbarjTradX88LTjTPfY-/view?usp=sharing  ");
        }

        else if (paper_position==5) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/1KxBg0lP3s7g6zIpdFGV1Fr0FwiJo-eY2/view?usp=sharing   ");
        }

        else if (paper_position==6) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/1EgA3CNFJCJHw5NpSgs8gmLk79eyThgho/view?usp=sharing  ");
        }

        else if (paper_position==7) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/187WqrcoLyk1i0tRfdTvHs_YaBxhyx5AG/view?usp=sharing ");
        }

        else if (paper_position==8) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/18ADofipRmIx26y8QYUTo3X3e2cmxDQu5/view?usp=sharing ");
        }

        else if (paper_position==9) {
            myWebViewBsc3YearNotes.loadUrl("https://drive.google.com/file/d/1EeRoYgurwy27ugqbfAZ43kjDUNvTFZlH/view?usp=sharing  ");
        }


    }
}