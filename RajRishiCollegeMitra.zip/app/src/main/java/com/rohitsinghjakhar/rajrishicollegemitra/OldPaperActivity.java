package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;

public class OldPaperActivity extends AppCompatActivity {

    GridLayout MainGridLayout2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_paper);

        MainGridLayout2 = (GridLayout) findViewById(R.id.MainGridLayout2);

        setSingleEvent(MainGridLayout2);
    }

    private void setSingleEvent(GridLayout mainGridLayout1) {
        for (int i = 0; i < MainGridLayout2.getChildCount(); i++) {
            CardView cardView = (CardView) MainGridLayout2.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (finalI == 0) {
                        Intent intent = new Intent(OldPaperActivity.this, Bsc1paperActivity.class);
                        startActivity(intent);
                    } else if (finalI == 1) {
                        Intent intent = new Intent(OldPaperActivity.this, Msc1Activity.class);
                        startActivity(intent);
                    } else if (finalI == 2) {
                        Intent intent = new Intent(OldPaperActivity.this, Bsc2paperActivity.class);
                        startActivity(intent);
                    } else if (finalI == 3) {
                        Intent intent = new Intent(OldPaperActivity.this, MscFinalActivity.class);
                        startActivity(intent);
                    } else if (finalI == 4) {
                        Intent intent = new Intent(OldPaperActivity.this, Bsc3paperActivity.class);
                        startActivity(intent);
                    }

                }
            });
        }
    }
}