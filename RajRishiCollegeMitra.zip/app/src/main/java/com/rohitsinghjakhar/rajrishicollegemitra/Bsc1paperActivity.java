package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

public class Bsc1paperActivity extends AppCompatActivity {

    private AdView mAdView;

    Button pp1sem;
    Button pp2sem;
    Button pc1sem;
    Button pc2sem;
    Button pm1sem;
    Button pm2sem;
    Button pb1sem;
    Button pb2sem;
    Button pz1sem;
    Button pz2sem;
    Button phindi1sem;
    Button peng1sem;
    Button pcomp1sem;
    Button pstudy1sem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bsc1paper);



        pp1sem = findViewById(R.id.pp1sem);
        pp2sem = findViewById(R.id.pp2sem);
        pc1sem = findViewById(R.id.pc1sem);
        pc2sem = findViewById(R.id.pc2sem);
        pm1sem = findViewById(R.id.pm1sem);
        pm2sem = findViewById(R.id.pm2sem);
        pb1sem = findViewById(R.id.pb1sem);
        pb2sem = findViewById(R.id.pb2sem);
        pz1sem = findViewById(R.id.pz1sem);
        pz2sem = findViewById(R.id.pz2sem);
        phindi1sem = findViewById(R.id.phindi1sem);
        peng1sem = findViewById(R.id.peng1sem);
        pcomp1sem = findViewById(R.id.pcomp1sem);
        pstudy1sem = findViewById(R.id.pstudy1sem);


        pp1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Sorry", Toast.LENGTH_SHORT).show();
                gotoUrl("https://rajrishicollegealwar.blogspot.com/");
            }
        });

        pp2sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Physics 2nd Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1bIIhuKD2-yZrTOh5gwKS_BT-AJvNR9LY/view?usp=sharing");
            }
        });

        pc1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Chemistry 1st Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1KoHu3IiWTjqSk33-pftSwP8iCQ8ZC6i4/view?usp=sharing");
            }
        });

        pc2sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Chemistry 2nd Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1Mxhnig6PHQZj4FR8-Jl8UR6Qn6Mhp-Kt/view?usp=sharing");
            }
        });

        pm1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Maths 1st Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1Kl544SQsd2mlQvKdIiEdy2FirSCxXtIA/view?usp=sharing");
            }
        });

        pm2sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Maths 2nd Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1bHj9u5kZqx_3cioicHapph4BlubEXJG4/view?usp=sharing");
            }
        });


        pb1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Botany 1st Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1KkxtfZsIEzCDXdou0gP1jW9A6wiYNkp3/view?usp=sharing");
            }
        });

        pb2sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Botany 2nd Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1Mdb-_X9nOYMekx-6wTIJ1dKRnx1kVzJq/view?usp=sharing");
            }
        });

        pz1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Zoology 1st Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1KkxtfZsIEzCDXdou0gP1jW9A6wiYNkp3/view?usp=sharing");
            }
        });

        pz2sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Zoology 2nd Sem. Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1Mxg0xIYjeizgCxBcuCLu9VGqrBhh8mQ4/view?usp=sharing");
            }
        });

        phindi1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Hindi Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1O1npyPGkNG-SFdfPAMxLc_l6bN19EzQc/view?usp=sharing");
            }
        });

        peng1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "English Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1NvSI_l3Z5gSkDpjKcEf8tG9VN9ao4gDN/view?usp=share_link");
            }
        });

        pcomp1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Computer Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1NmgYrBcr3-HYUuFJghc0fEJuBJT-ex1m/view?usp=sharing");
            }
        });

        pstudy1sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Bsc1paperActivity.this, "Environmental Study Old Papers opened", Toast.LENGTH_SHORT).show();
                gotoUrl("https://drive.google.com/file/d/1NoS11zqHwoTjK1FwCynpaMo86kZaym_9/view?usp=sharing");
            }
        });

    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));

        mAdView = findViewById(R.id.adView1year);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }


            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });


    }
}