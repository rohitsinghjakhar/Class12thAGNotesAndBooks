package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

public class OfficeActivity extends AppCompatActivity {

    private AdView mAdView;

    Button teaching;
    Button non;
    Button policy;
    Button fees;
    Button committee;
    Button timetable;
    Button information;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_office);

        teaching = findViewById(R.id.teaching);
        non = findViewById(R.id.non);
        policy = findViewById(R.id.policy);
        fees = findViewById(R.id.fees);
        committee = findViewById(R.id.committee);
        timetable = findViewById(R.id.timetable);
        information = findViewById(R.id.information);


        teaching.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1-uTHwP905OE7mtZln9oqedC53eMkYRvJ/view");
            }
        });

        non.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1owLRwL235Zk_-CByWfdrnFbYGGPprz1E/view");
            }
        });

        policy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1d-uLZKXVFNOuDSEUZyh8uj79y9q7FHsj/view");
            }
        });

        fees.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1c1Sy37aEAJD840XPCQv9Ik4OE4HwteEK/view");
            }
        });

        committee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://docs.google.com/document/d/1T88t1B3kzTDGFEPNFAhobDZcBcGqT3hO/edit?usp=sharing&ouid=111050631602082657728&rtpof=true&sd=true");
            }
        });

        timetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1enCjkOgc1jA7ZQjRwamCt9SO8yAp8b6d/view");
            }
        });

        information.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://rajrishicollegealwar.blogspot.com/");
            }
        });
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));


        mAdView = findViewById(R.id.adViewoffice);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }


            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });
    }
}