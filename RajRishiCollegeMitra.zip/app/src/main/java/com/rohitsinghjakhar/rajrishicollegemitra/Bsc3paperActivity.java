package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

public class Bsc3paperActivity extends AppCompatActivity {

    private AdView mAdView;

    Button pp5sem;
    Button pp6sem;
    Button pc5sem;
    Button pc6sem;
    Button pm5sem;
    Button pm6sem;
    Button pb5sem;
    Button pz5sem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bsc3paper);

        pp5sem = findViewById(R.id.pp5sem);
        pp6sem = findViewById(R.id.pp6sem);
        pc5sem = findViewById(R.id.pc5sem);
        pc6sem = findViewById(R.id.pc6sem);
        pm5sem = findViewById(R.id.pm5sem);
        pm6sem = findViewById(R.id.pm6sem);
        pb5sem = findViewById(R.id.pb5sem);
        pz5sem = findViewById(R.id.pz5sem);


        pp5sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1P2u6F621ev5L60uY1_TTmeHikDiL3DOX/view?usp=sharing");
            }
        });

        pp6sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1PTy4eMVb63_30x46MAvqF8xhgIf57KfO/view?usp=sharing");
            }
        });

        pc5sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1P3CHQxy6pltbMjR8Pp6cUJ8-grxEp67u/view?usp=sharing");
            }
        });

        pc6sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1PXKcphqjVeqnz5UcnUqa3El0UQyM-W6o/view?usp=sharing");
            }
        });

        pm5sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1P-tthvSB5bJoRIwpzRihPxPrXz_Al6X3/view?usp=sharing");
            }
        });

        pm6sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1P-tthvSB5bJoRIwpzRihPxPrXz_Al6X3/view?usp=sharing");
            }
        });


        pb5sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1EDnf4Xf1QtN4XFIHb_C9Cgo22Yjz5Rvf/view?usp=sharing");
            }
        });

        pz5sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1CxuZjNkIZ8izVcU4i1EykeRObBNQhPwk/view?usp=sharing");
            }
        });
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));

        mAdView = findViewById(R.id.adViewp3year);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }


            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });

    }
}