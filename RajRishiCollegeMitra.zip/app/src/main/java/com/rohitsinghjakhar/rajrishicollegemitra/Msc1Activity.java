package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class Msc1Activity extends AppCompatActivity {

    Button qmprevyear;
    Button edprevyear;
    Button cm1stunit;
    Button ed1stunit;
    Button ed3rdunit;
    Button ed4thunit;
    Button ele1stunit;
    Button ele3rdunit;
    Button qm2ndunit;


    private AdView mAdView;
    private InterstitialAd mInterstitialAd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msc1);

        qmprevyear = findViewById(R.id.qmprevyear);
        edprevyear = findViewById(R.id.edprevyear);
        cm1stunit = findViewById(R.id.cm1stunit);
        ed1stunit = findViewById(R.id.ed1stunit);
        ed3rdunit = findViewById(R.id.ed3rdunit);
        ed4thunit = findViewById(R.id.ed4thunit);
        ele1stunit = findViewById(R.id.ele1stunit);
        ele3rdunit = findViewById(R.id.ele3rdunit);
        qm2ndunit = findViewById(R.id.qm2ndunit);


        qmprevyear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/125D9fsGZhSpNLmf3SQ9WqGyJgTCfSWxS/view?usp=sharing");

                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Quantum Mechanics Notes opened ", Toast.LENGTH_SHORT).show();

                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/3808672868", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        edprevyear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/12Adl-ls-b0pUdcaC0u6wzmqhU69GJlMt/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Electrodynamics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/3808672868", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        cm1stunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1H5XFCvz13fxBs_CVY5vJ6fiaPdPKyH_C/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Classical Mechanics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/1182509524", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        ed1stunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1HMJvYNIgZvhz3ylKBgV34civa4-kc22i/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Electrodynamics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/1182509524", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        ed3rdunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1HPIkfZNrVzXfyD92Ytjaur8VOVxIH-WQ/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Electrodynamics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/1182509524", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        ed4thunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1HUOnbK_9fV2dmaGXxpLg6-xIJAOUJiTk/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Electrodynamics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/1182509524", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        ele1stunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1Gv5H1nHVuZL3KpIJeHeRXPzPh5pySQPV/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Electronics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/1182509524", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        ele3rdunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1H5S0nA1x5UbCKmEvHqJWOOnOhplBabku/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Electronics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/3808672868", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        qm2ndunit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://drive.google.com/file/d/1HK450IHUfOHRgR0jIaUMMLrOzx_qVPre/view?usp=sharing");
                Toast.makeText(Msc1Activity.this, "M.Sc. Prev. Year Quantum Mechanics Notes opened ", Toast.LENGTH_SHORT).show();
                InterstitialAd.load(Msc1Activity.this, "ca-app-pub-7613081539380006/3808672868", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = Msc1Activity.this.mInterstitialAd = null;
                    }
                });
            }
        });

        mAdView = findViewById(R.id.adViewprev);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });

        if (mInterstitialAd != null) {
            mInterstitialAd.show(Msc1Activity.this);
        } else {
            Log.d("TAG", "The interstitial ad wasn't ready yet.");
        }

    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));

    }
}