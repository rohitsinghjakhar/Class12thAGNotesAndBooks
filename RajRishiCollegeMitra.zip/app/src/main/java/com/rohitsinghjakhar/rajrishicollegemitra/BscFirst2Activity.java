package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class BscFirst2Activity extends AppCompatActivity {

    private AdView mAdView;
    WebView myWebViewBsc1YearNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bsc_first2);

        myWebViewBsc1YearNotes = (WebView) findViewById(R.id.myWebViewBsc1YearNotes);
        myWebViewBsc1YearNotes.setWebViewClient(new WebViewClient());
        WebSettings webSettings = myWebViewBsc1YearNotes.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mAdView = findViewById(R.id.adView1year2);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        int paper_position=getIntent().getIntExtra("bsc1yearnotespdf",0);

        if (paper_position==0) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1MMZr9wyEbID_ChVl_brCzFSyuvqui9ld/view?usp=sharing");
        }

        else if (paper_position==1) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1NEqaHiem4i60VKrx5jdYl2ZYNpCf9N4b/view?usp=sharing");
        }

        else if (paper_position==2) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1uC5E-cGGBwc3Tz1eGRwtVOtL6b7rfIIZ/view?usp=sharing");
        }

        else if (paper_position==3) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1N-LKszUjU-sdj5owetKIdkQc3DIQJL95/view?usp=sharing");
        }

        else if (paper_position==4) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1UWdll8GDzMG6LXwDzAZpyGQw7eVrnH4n/view?usp=sharing");
        }

        else if (paper_position==5) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/13YB7xIYumiL0CjGw6Q8QFhRLVvKz-GFe/view?usp=sharing   ");
        }

        else if (paper_position==6) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1NCfsp65_XLO4B3QqWPiY03vA2XicQJke/view?usp=sharing");
        }

        else if (paper_position==7) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/11ThGxgcCkZQCacpaDOyAK6gmGzWoAeYk/view?usp=sharing");
        }

        else if (paper_position==8) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/11ThGxgcCkZQCacpaDOyAK6gmGzWoAeYk/view?usp=sharing");
        }

        else if (paper_position==9) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/11T5Dzr-xWKo44y7UegLnbpqpqJAIZXJk/view?usp=sharing");
        }

        else if (paper_position==10) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/11T5Dzr-xWKo44y7UegLnbpqpqJAIZXJk/view?usp=sharing");
        }

        else if (paper_position==11) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/11T5Dzr-xWKo44y7UegLnbpqpqJAIZXJk/view?usp=sharing");
        }

        else if (paper_position==12) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1p5Qclr-FVbHbqMBfs-wvcGqUsx3tXeko/view?usp=sharing");
        }

        else if (paper_position==13) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1oyOt8mfSzhQAxkuEnrYxgCD6-YUR4EnA/view?usp=sharing");
        }

        else if (paper_position==14) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1qTvcDqBlxgcoKt4DrJsKHPdx0mJAzIEF/view?usp=sharing");
        }

        else if (paper_position==15) {
            myWebViewBsc1YearNotes.loadUrl("https://drive.google.com/file/d/1p-sY0EmefyjUQ7ZieawSCT_RpDmOP1e9/view?usp=sharing");
        }



    }
}