package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class Books2Activity extends AppCompatActivity {

    WebView myWebViewbooks;
    private AdView mAdView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books2);

        myWebViewbooks = (WebView) findViewById(R.id.myWebViewbooks);
        myWebViewbooks.setWebViewClient(new WebViewClient());
        WebSettings webSettings = myWebViewbooks.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mAdView = findViewById(R.id.adViewbooks2);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        int paper_position=getIntent().getIntExtra("bookscollege",0);

        if (paper_position==0) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1c8sXxHMTyx4tQLdGVpGAy9vXz0SXXiCa/view?usp=sharing");
        }

        else if (paper_position==1) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1eSOorxLFGKc2KV7s2uFnzY-Ps4wDAWby/view?usp=sharing");
        }

        else if (paper_position==2) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1eOIZuciGiYHL9yLsdE19k3kgTOuiEk5S/view?usp=sharing");
        }

        else if (paper_position==3) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1ueJelPn4OCfsb5UOAp3ZV9pbFjVjV62r/view?usp=sharing ");
        }

        else if (paper_position==4) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1N3BAU3_Qb8gcdxlRfvUJfRJivA5GdmEG/view?usp=sharing  ");
        }

        else if (paper_position==5) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1O9Y7_qKUehi2SNO8_64BKEbWDbwIFhOO/view?usp=sharing  ");
        }

        else if (paper_position==6) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1RIQqOlVCWlWoIl98307KYlcaTHqoD8wm/view?usp=sharing  ");
        }

        else if (paper_position==7) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1BPVCFPerEtix2d-U73kJVhybaDpq4W8W/view?usp=sharing  ");
        }

        else if (paper_position==8) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/19-KeCvPD23nyVfVFrETC2Y2IPtI6gK5a/view?usp=sharing  ");
        }

        else if (paper_position==9) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1pmp_mqYkdN7YFLcVT5tgl3iXEsP7l-ZS/view?usp=sharing  ");
        }

        else if (paper_position==10) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1a0INd-3rAWMpSCKGWTIBybVjBq2agl7c/view?usp=sharing  ");
        }

        else if (paper_position==11) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1NJCR801TMCQvnRAAFc5uNUixWmWeNpsF/view?usp=sharing  ");
        }

        else if (paper_position==12) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/15T-luaaiYHFKT5hIRma_FWNXIFfCLpbW/view?usp=sharing  ");
        }

        else if (paper_position==13) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/15GvG1Mivdd4UZ0zbSPB067KD2owvxeV8/view?usp=sharing  ");
        }

        else if (paper_position==14) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1smLX2g4rqpSUR0b5Hi-QSOjILErGsmZ9/view?usp=sharing  ");
        }

        else if (paper_position==15) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1OP8QpHNMYTOU2wBtuqksv1C0DE8AjukF/view?usp=sharing  ");
        }

        else if (paper_position==16) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1NCWQB1WwINc4wTayFD63LwanXKjuEQOK/view?usp=sharing  ");
        }

        else if (paper_position==17) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1ykEyaj1en2VkD1gMJGxOxuSr8CHfh1n9/view?usp=sharing  ");
        }

        else if (paper_position==18) {
            myWebViewbooks.loadUrl("https://drive.google.com/file/d/1B_ev0GPYv7kxWHWOt3USSO4LmnHB0A53/view?usp=sharing  ");
        }

        else if (paper_position==19) {
            myWebViewbooks.loadUrl("https://drive.google.com/drive/folders/1Ijnx0CnKWV3XYHLanADIKW9TGbfE9K9R  ");
        }





    }
}