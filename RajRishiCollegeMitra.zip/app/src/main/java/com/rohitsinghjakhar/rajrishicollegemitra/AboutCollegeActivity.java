package com.rohitsinghjakhar.rajrishicollegemitra;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.Objects;

public class AboutCollegeActivity extends AppCompatActivity {


    Button CollegeWebsite;
    Button CollegeWebsite2;
    Button hpwebsite;
    Button result;
    private InterstitialAd mInterstitialAd;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_college);

        CollegeWebsite = findViewById(R.id.CollegeWebsite);
        CollegeWebsite2 = findViewById(R.id.CollegeWebsite2);
        hpwebsite = findViewById(R.id.hpwebsite);
        result = findViewById(R.id.result);

        CollegeWebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://rrcalwar.onlineexamforms.com");
                InterstitialAd.load(AboutCollegeActivity.this, "ca-app-pub-7613081539380006/8353396499", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = null;
                    }
                });
                if (AboutCollegeActivity.this.mInterstitialAd != null) {
                    AboutCollegeActivity.this.mInterstitialAd.show(AboutCollegeActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });

        CollegeWebsite2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://hte.rajasthan.gov.in/college/gcalwar");
                InterstitialAd.load(AboutCollegeActivity.this, "ca-app-pub-7613081539380006/8353396499", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = null;
                    }
                });
                if (AboutCollegeActivity.this.mInterstitialAd != null) {
                    AboutCollegeActivity.this.mInterstitialAd.show(AboutCollegeActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });

        hpwebsite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://rajrishicollegealwar.blogspot.com/");
                InterstitialAd.load(AboutCollegeActivity.this, "ca-app-pub-7613081539380006/8353396499", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = null;
                    }
                });
                if (AboutCollegeActivity.this.mInterstitialAd != null) {
                    AboutCollegeActivity.this.mInterstitialAd.show(AboutCollegeActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });

        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://rajrishicollegealwar.blogspot.com/2022/08/rr-result.html");
                InterstitialAd.load(AboutCollegeActivity.this, "ca-app-pub-7613081539380006/8353396499", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = AboutCollegeActivity.this.mInterstitialAd = null;
                    }
                });
                if (AboutCollegeActivity.this.mInterstitialAd != null) {
                    AboutCollegeActivity.this.mInterstitialAd.show(AboutCollegeActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });


    }
    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }
}