package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

public class CollegeLinksActivity extends AppCompatActivity {

    private AdView mAdView;

    Button rrchelper;
    Button website;
    Button rrbmu;
    Button info;
    Button colleges;
    Button content;
    Button ugc;

    Button bser;
    Button ncc;
    Button scout;
    Button naac;
    Button election;
    Button portal;
    Button sc;
    Button aadhar;
    Button pancard;
    Button passport;
    Button rbi;
    Button bsnl;
    Button finance;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_college_links);

        rrchelper = findViewById(R.id.rrchelper);
        website = findViewById(R.id.website);
        rrbmu = findViewById(R.id.rrbmu);
        info = findViewById(R.id.info);
        colleges = findViewById(R.id.colleges);
        content = findViewById(R.id.content);
        ugc = findViewById(R.id.ugc);
        bser = findViewById(R.id.bser);
        ncc = findViewById(R.id.ncc);
        scout = findViewById(R.id.scout);
        naac = findViewById(R.id.naac);
        election = findViewById(R.id.election);
        portal = findViewById(R.id.portal);
        sc = findViewById(R.id.sc);
        aadhar = findViewById(R.id.aadhar);
        pancard = findViewById(R.id.pancard);
        passport = findViewById(R.id.passport);
        rbi = findViewById(R.id.rbi);
        bsnl = findViewById(R.id.bsnl);
        finance = findViewById(R.id.finance);



        rrchelper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://rajrishicollegealwar.blogspot.com/");
            }
        });


        website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://hte.rajasthan.gov.in/college/gcalwar");
            }
        });

        rrbmu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.rrbmuniv.ac.in/");
            }
        });

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://rajrishicollegealwar.blogspot.com/");
            }
        });


        colleges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.ugc.ac.in/oldpdf/colleges/List%20of%20colleges%20as%20on%2031082020.pdf");
            }
        });


        content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/drive/folders/1VK_q8rzwSBFwTrxJgU8SmVRMoKbwFrRU");
            }
        });

        ugc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.ugc.ac.in/");
            }
        });

        bser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://rajeduboard.rajasthan.gov.in/");
            }
        });

        ncc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://naac.gov.in/index.php/en/");
            }
        });

        scout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://uat.bsgindia.org/");
            }
        });

        naac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("http://naac.gov.in/index.php/en/");
            }
        });

        election.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://eci.gov.in/");
            }
        });

        portal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.india.gov.in//");
            }
        });

        sc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://main.sci.gov.in/");
            }
        });

        aadhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://uidai.gov.in/");
            }
        });

        pancard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.pan.utiitsl.com/");
            }
        });

        passport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.passportindia.gov.in/AppOnlineProject/welcomeLink");
            }
        });

        rbi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.rbi.org.in/");
            }
        });

        bsnl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.bsnl.co.in/");
            }
        });

        finance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://www.finmin.nic.in/");
            }
        });

    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));


        mAdView = findViewById(R.id.adViewlinks);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }


            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });

    }
}