package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

public class Bsc2paperActivity extends AppCompatActivity {

    private AdView mAdView;

    Button pp3sem;
    Button pp4sem;
    Button pc3sem;
    Button pc4sem;
    Button pm3sem;
    Button pm4sem;
    Button pb3sem;
    Button pb4sem;
    Button pz3sem;
    Button pz4sem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bsc2paper);

        pp3sem = findViewById(R.id.pp3sem);
        pp4sem = findViewById(R.id.pp4sem);
        pc3sem = findViewById(R.id.pc3sem);
        pc4sem = findViewById(R.id.pc4sem);
        pm3sem = findViewById(R.id.pm3sem);
        pm4sem = findViewById(R.id.pm4sem);
        pb3sem = findViewById(R.id.pb3sem);
        pb4sem = findViewById(R.id.pb4sem);
        pz3sem = findViewById(R.id.pz3sem);
        pz4sem = findViewById(R.id.pz4sem);




        pp3sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1OufqCS13hhetvqbBwDIYOXA4SqaP1liD/view?usp=sharing");
            }
        });

        pp4sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1d65ZXztKBsccYLKlgcxJp6ya-XZfaxYc/view?usp=sharing");
            }
        });

        pc3sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1tmep4whbnOxItrq3aqcfXsN02OMCUmhG/view?usp=sharing");
            }
        });

        pc4sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1NpT7VINomtVxeGC-6YG705hk85WMKGFw/view?usp=sharing");
            }
        });

        pm3sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1SLous__IUEtyP_5laXzokd_SITmx8lbZ/view?usp=sharing");
            }
        });

        pm4sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1Np_o8ubXqAjWE8r9llcSTp5LtETscJHr/view?usp=sharing");
            }
        });

        pb3sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1OjebIpIuweGlNLvYRjb2vx_R-1gIW0vU/view?usp=sharing");
            }
        });

        pb4sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("no file");
            }
        });

        pz3sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://drive.google.com/file/d/1NOR8X75BaY8hYboRNkuwHh04cqGzTR3r/view?usp=sharing");
            }
        });

        pz4sem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("no file");
            }
        });
    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));


        mAdView = findViewById(R.id.adViewp2year);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }


            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });
    }
}