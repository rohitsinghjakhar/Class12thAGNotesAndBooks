package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class EarnMoneyActivity extends AppCompatActivity {

    private InterstitialAd mInterstitialAd;
    private AdView mAdView;

    Button instagram1;
    Button upstox;
    Button angel;
    Button icici;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_earn_money);

        instagram1 = findViewById(R.id.instagram1);
        upstox = findViewById(R.id.upstox);
        angel = findViewById(R.id.angel);
        icici = findViewById(R.id.icici);

        instagram1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.instagram.com/rohit.singh.jakhar/");

                InterstitialAd.load(EarnMoneyActivity.this, "ca-app-pub-7613081539380006/8676830127", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = null;
                    }
                });
                if (EarnMoneyActivity.this.mInterstitialAd != null) {
                    EarnMoneyActivity.this.mInterstitialAd.show(EarnMoneyActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }


            }
        });

        upstox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://link.upstox.com/WDpq");
                InterstitialAd.load(EarnMoneyActivity.this, "ca-app-pub-7613081539380006/8676830127", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = null;
                    }
                });
                if (EarnMoneyActivity.this.mInterstitialAd != null) {
                    EarnMoneyActivity.this.mInterstitialAd.show(EarnMoneyActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });

        angel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://play.google.com/store/apps/details?id=com.msf.angelmobile&referrer=515709ryR::rne_source=Earn_Rewards_FnO::rne_field2=Earn_Rewards_FnO");
                InterstitialAd.load(EarnMoneyActivity.this, "ca-app-pub-7613081539380006/9986042360", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = null;
                    }
                });
                if (EarnMoneyActivity.this.mInterstitialAd != null) {
                    EarnMoneyActivity.this.mInterstitialAd.show(EarnMoneyActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });

        icici.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://secure.icicidirect.com/accountopening?rfrlcode=8506947575&utm_medium=referral&utm_source=all");
                InterstitialAd.load(EarnMoneyActivity.this, "ca-app-pub-7613081539380006/8353396499", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = EarnMoneyActivity.this.mInterstitialAd = null;
                    }
                });
                if (EarnMoneyActivity.this.mInterstitialAd != null) {
                    EarnMoneyActivity.this.mInterstitialAd.show(EarnMoneyActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });

        mAdView = findViewById(R.id.adViewmoney);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }


            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });


    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }


}