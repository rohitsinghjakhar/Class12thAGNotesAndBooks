package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;

public class ClassesActivity extends AppCompatActivity {

    GridLayout MainGridLayout1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classes);

        MainGridLayout1 =(GridLayout) findViewById(R.id.MainGridLayout1);

        setSingleEvent(MainGridLayout1);
    }

    private void setSingleEvent(GridLayout mainGridLayout1) {
        for(int i=0; i<MainGridLayout1.getChildCount();i++)
        {
            CardView cardView = (CardView)MainGridLayout1.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (finalI == 0) {
                        Intent intent = new Intent(ClassesActivity.this, BscFirstActivity.class);
                        startActivity(intent);
                    } else if (finalI == 1) {
                        Intent intent = new Intent(ClassesActivity.this, Msc1Activity.class);
                        startActivity(intent);
                    } else if (finalI == 2) {
                        Intent intent = new Intent(ClassesActivity.this, BscSecondActivity.class);
                        startActivity(intent);
                    } else if (finalI == 3) {
                        Intent intent = new Intent(ClassesActivity.this, MscFinalActivity.class);
                        startActivity(intent);
                    } else if (finalI == 4) {
                        Intent intent = new Intent(ClassesActivity.this, BscThirdActivity.class);
                        startActivity(intent);
                    }

                }
            });
        }
    }
}
