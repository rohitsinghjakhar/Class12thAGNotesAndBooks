package com.rohitsinghjakhar.rajrishicollegemitra;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import java.util.ArrayList;
import java.util.List;

public class BooksActivity extends AppCompatActivity {


    private AdView mAdView;
    ListView listViewBook;

    Button inorganic1year;
    Button organic1year;
    Button physical1year;
    Button mechanics1year;
    Button waves1year;
    Button hindi1year;
    Button zoology2year;
    Button inorganic3year;
    Button organic3year;
    Button physical3year;
    Button algebra3year;
    Button complex3year;
    Button mathephysics3year;
    Button nuclear3year;
    Button solidstate3year;
    Button MScPrevBook;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);

        listViewBook=findViewById(R.id.ListViewBook);
        String[] collegebooks =getResources().getStringArray(R.array.College_Books);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_activated_1,collegebooks);

        listViewBook.setAdapter(adapter);

        listViewBook.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(BooksActivity.this,Books2Activity.class);
                intent.putExtra("bookscollege",position);
                startActivity(intent);

                AdRequest adRequest = new AdRequest.Builder().build();

            }


        });




                mAdView = findViewById(R.id.adViewbooks);
                AdRequest adRequest = new AdRequest.Builder().build();
                mAdView.loadAd(adRequest);

                mAdView.setAdListener(new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        super.onAdLoaded();
                        // Code to be executed when an ad finishes loading.
                    }


                    @Override
                    public void onAdFailedToLoad(LoadAdError adError) {
                        // Code to be executed when an ad request fails.
                        super.onAdFailedToLoad(adError);
                        mAdView.loadAd(adRequest);
                    }

                    @Override
                    public void onAdOpened() {
                        // Code to be executed when an ad opens an overlay that
                        // covers the screen.
                        super.onAdOpened();
                    }

                    @Override
                    public void onAdClicked() {
                        // Code to be executed when the user clicks on an ad.
                        super.onAdClicked();
                    }

                    @Override
                    public void onAdClosed() {
                        // Code to be executed when the user is about to return
                        // to the app after tapping on an ad.
                    }
                });


            }

            private void gotoUrl(String s) {
                Uri uri = Uri.parse(s);
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            }
    }
