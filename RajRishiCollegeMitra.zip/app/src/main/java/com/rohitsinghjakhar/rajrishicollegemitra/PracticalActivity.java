package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;

import java.util.ArrayList;

public class PracticalActivity extends AppCompatActivity {

    private AdView mAdView;

    ListView listView1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical);

        listView1 = findViewById(R.id.listview1);

        ArrayList<String> arrPractical = new ArrayList<>();
        ArrayList<Integer> image=new ArrayList<>();





        arrPractical.add("B.Sc. 1st Year Physics ");
        arrPractical.add("B.Sc. 1st Year Chemistry ");
        arrPractical.add("B.Sc. 1st Year Maths ");
        arrPractical.add("B.Sc. 1st Year Botany ");
        arrPractical.add("B.Sc. 1st Year Zoology ");
        arrPractical.add("B.Sc. 2nd Year Physics ");
        arrPractical.add("B.Sc. 2nd Year Chemistry ");
        arrPractical.add("B.Sc. 2nd Year Maths ");
        arrPractical.add("B.Sc. 2nd Year Botany ");
        arrPractical.add("B.Sc. 2nd Year Zoology ");
        arrPractical.add("B.Sc. 3rd Year Physics ");
        arrPractical.add("B.Sc. 3rd Year Chemistry ");
        arrPractical.add("B.Sc. 3rd Year Maths");
        arrPractical.add("B.Sc. 3rd Year Botany ");
        arrPractical.add("B.Sc. 3rd Year Zoology ");
        arrPractical.add("M.Sc. Prev. Year Physics ");




        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);
        image.add(R.drawable.ic_baseline_book_24);



        MyAdapter myAdapter=new MyAdapter(this,arrPractical,image);
        listView1.setAdapter(myAdapter);

        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0) {
                    gotoUrl("https://drive.google.com/file/d/1MutJof230t9KGG_Mq5uL3pDFRtqoCuL9/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "1st Year Physics File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==1) {
                    gotoUrl("https://drive.google.com/file/d/1MnmX20SztNLx2ErsdYOY4A4GdQ6u-phP/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "1st Year Chemistry File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==2) {
                    gotoUrl("");
                    Toast.makeText(PracticalActivity.this, "Sorry", Toast.LENGTH_SHORT).show();
                } else if (i==3) {
                    gotoUrl("https://drive.google.com/file/d/1wu7Ek0EDb8CYPNCbFyWNFbVofbGl-vH9/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "1st Year Botany File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==4) {
                    gotoUrl("https://drive.google.com/file/d/1ycGM75axYlBgRwQRKfza9b12Qd5HfWQb/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "1st Year Zoology File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==5) {
                    gotoUrl("https://drive.google.com/file/d/1MrecBvYpLnz8TdOq0NJrK2M3caNXNKtt/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "2nd Year Physics File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==6) {
                    gotoUrl("https://drive.google.com/file/d/1HK9rr3qFvwscigyylABr4YLZ1hm72Jyl/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "2nd Year Chemistry File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==7) {
                    gotoUrl("https://drive.google.com/file/d/1OjV8bc6fXggH2r4l6SK9QPS28wjSifTB/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "2nd Year Maths File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==8) {
                    gotoUrl("https://drive.google.com/file/d/1oIwWUKiSBySqrQGqSCzRJIJpy0n6Kx3t/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "2nd Year Botany File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==9) {
                    gotoUrl("https://drive.google.com/file/d/1nx8mB1orwL3aF782EbDFLchqAEVbOwrz/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "2nd Year Zoology File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==10) {
                    gotoUrl("https://drive.google.com/file/d/1qbd9SwtofH5jd_BNe3SgScPHMGnzPAtK/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "3rd Year Physics File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==11) {
                    gotoUrl("https://drive.google.com/file/d/1qcs3W8bsdUZi7uunoUBmBeWcKv1OgbtO/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "3rd Year Chemistry File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==12) {
                    gotoUrl("https://drive.google.com/file/d/1qaJuoXN4D4Ug7rn0xkfKRIw1H5_esjPX/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "3rd Year Maths File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==13) {
                    gotoUrl("https://drive.google.com/file/d/1q_dIKil_vWmEeJMAczO5pcWg7KtJxNmn/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "3rd Year Botany File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==14) {
                    gotoUrl("https://drive.google.com/file/d/1qWOOEEqIdhtnknnHkFTh1Wilod4fkTkq/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "3rd Year Zoology File Opened", Toast.LENGTH_SHORT).show();
                } else if (i==15) {
                    gotoUrl("https://drive.google.com/file/d/11Yb6mmzA6NQrztyHqXoCpa67UPbSuOFO/view?usp=sharing");
                    Toast.makeText(PracticalActivity.this, "M.Sc. Prev. Year Physics File Opened", Toast.LENGTH_SHORT).show();
                }
            }
        });




        mAdView = findViewById(R.id.adViewpractical);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                // Code to be executed when an ad finishes loading.
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                super.onAdFailedToLoad(adError);
                mAdView.loadAd(adRequest);
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
                super.onAdOpened();
            }

            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
                super.onAdClicked();
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }
        });



    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }


}