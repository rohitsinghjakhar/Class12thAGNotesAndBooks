package com.rohitsinghjakhar.rajrishicollegemitra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class BscSecond2Activity extends AppCompatActivity {

    private AdView mAdView;
    WebView myWebViewBsc2YearNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bsc_second2);

        myWebViewBsc2YearNotes = (WebView) findViewById(R.id.myWebViewBsc2YearNotes);
        myWebViewBsc2YearNotes.setWebViewClient(new WebViewClient());
        WebSettings webSettings = myWebViewBsc2YearNotes.getSettings();
        webSettings.setJavaScriptEnabled(true);

        mAdView = findViewById(R.id.adView2year2);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        int paper_position=getIntent().getIntExtra("bsc2yearnotespdf",0);

        if (paper_position==0) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/13WH-cY1mCITcyhoVnVlYqb2KFB3SOK3a/view?usp=sharing  ");
        }

        else if (paper_position==1) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/1rD9NkfZHjYCE3QxjiKeAnBdbRBXmBarV/view?usp=sharing   ");
        }

        else if (paper_position==2) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/15AQ_nO-TedaTXDh36qZPZZfOAS8u4LZI/view?usp=sharing  ");

        }

        else if (paper_position==3) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/14uqdd97De3tjw0kkedVCPLggEPlsFpjV/view?usp=sharing  ");
        }

        else if (paper_position==4) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/1SSzXUhXT4DYaJ6eCKwksCgotRZ-IaV0N/view?usp=sharing   ");
        }

        else if (paper_position==5) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/15KiP8Zt0jjqv3-3QHNL0VxwcZSoG-B_2/view?usp=sharing  ");

        }

        else if (paper_position==6) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/1qTVA-It7lpZc32XZ8ymkOGX_RpyODJ98/view?usp=sharing");
        }

        else if (paper_position==7) {
            myWebViewBsc2YearNotes.loadUrl("https://drive.google.com/file/d/1qTVA-It7lpZc32XZ8ymkOGX_RpyODJ98/view?usp=sharing");
        }


    }
}