package com.rohitsinghjakhar.rajrishicollegemitra;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

public class MainActivity extends AppCompatActivity {


    GridLayout MainGridLayout;
    Button disclaimer;
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;
    ImageView rateme;
    ImageView shareapp;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        new AdRequest.Builder().build();
        disclaimer = findViewById(R.id.disclaimer);
        rateme = findViewById(R.id.rateme);
        shareapp = findViewById(R.id.shareapp);

        disclaimer.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.gotoUrl("https://drive.google.com/file/d/18vO7MiexvKBDuTi2sb2sZXDDK8bovtZG/view?usp=sharing");
                InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/8676830127", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                    public void onAdLoaded(InterstitialAd interstitialAd) {
                        InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                        Log.i("ContentValues", "onAdLoaded");
                    }

                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        Log.i("ContentValues", loadAdError.getMessage());
                        InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                    }
                });
                if (MainActivity.this.mInterstitialAd != null) {
                    MainActivity.this.mInterstitialAd.show(MainActivity.this);
                } else {
                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
                }
            }
        });



        rateme.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MainActivity.this.gotoUrl("https://play.google.com/store/apps/details?id=com.rohitsinghjakhar.rajrishicollegemitra");
            }
        });



        shareapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent shareapp = new Intent(Intent.ACTION_SEND);
                shareapp.setType("text/plain");
                shareapp.putExtra(Intent.EXTRA_TEXT, "I really enjoyed Raj Rishi College Mitra app. *Thank you Rohit Bhaiya*. Download this Amazing App for College Notes, Books, Syllabus, Videos etc... https://play.google.com/store/apps/details?id=com.rohitsinghjakhar.rajrishicollegemitra");
                startActivity(Intent.createChooser(shareapp, "Share via"));
            }
        });



        GridLayout gridLayout = (GridLayout) findViewById(R.id.MainGridLayout);
        this.MainGridLayout = gridLayout;
        setSingleEvent(gridLayout);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder alertDailog =new AlertDialog.Builder(MainActivity.this);
        alertDailog.setTitle("Exit App");
        alertDailog.setMessage("Do you want to exit Raj Rishi College App?");
        alertDailog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finishAffinity();
            }
        });
        alertDailog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDailog.show();
    }

    public void gotoUrl(String str) {
        startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
    }

    private void setSingleEvent(GridLayout gridLayout) {
        for(int i=0; i<MainGridLayout.getChildCount();i++)
        {
            CardView cardView = (CardView)MainGridLayout.getChildAt(i);
            final int finalI = i;
            (this.MainGridLayout.getChildAt(i)).setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    int i = finalI;
                    if (i == 0) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, CollegeIntroActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/8676830127", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 1) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, SyllabusActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/1189539571", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 2) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, ClassesActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/1189539571", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 3) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, VideosActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/1189539571", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 4) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, BooksActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/8676830127", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 5) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, OfficeActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/2083818844", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 6) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, CollegeLinksActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/2083818844", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 7) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, CourseActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/2083818844", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 8) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, OldPaperActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/1101909660", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 9) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, PracticalActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/1101909660", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 10) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, AboutUsActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/1101909660", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 11) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, AboutCollegeActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/5671710068", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 12) {
                        MainActivity.this.startActivity(new Intent(MainActivity.this, ForStudentsActivity.class));
                        InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/5671710068", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                            public void onAdLoaded(InterstitialAd interstitialAd) {
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                Log.i("ContentValues", "onAdLoaded");
                            }

                            public void onAdFailedToLoad(LoadAdError loadAdError) {
                                Log.i("ContentValues", loadAdError.getMessage());
                                InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                            }
                        });
                        if (MainActivity.this.mInterstitialAd != null) {
                            MainActivity.this.mInterstitialAd.show(MainActivity.this);
                        } else {
                            Log.d("TAG", "The interstitial ad wasn't ready yet.");
                        }
                    } else if (i == 13) {
                            MainActivity.this.startActivity(new Intent(MainActivity.this, EarnMoneyActivity.class));
                            InterstitialAd.load(MainActivity.this, "ca-app-pub-7613081539380006/5671710068", new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                                public void onAdLoaded(InterstitialAd interstitialAd) {
                                    InterstitialAd unused = MainActivity.this.mInterstitialAd = interstitialAd;
                                    Log.i("ContentValues", "onAdLoaded");
                                }

                                public void onAdFailedToLoad(LoadAdError loadAdError) {
                                    Log.i("ContentValues", loadAdError.getMessage());
                                    InterstitialAd unused = MainActivity.this.mInterstitialAd = null;
                                }
                            });
                            if (MainActivity.this.mInterstitialAd != null) {
                                MainActivity.this.mInterstitialAd.show(MainActivity.this);
                            } else {
                                Log.d("TAG", "The interstitial ad wasn't ready yet.");
                            }
                        }

                }
            });
        }
        this.mAdView = (AdView) findViewById(R.id.adView);
        final AdRequest build = new AdRequest.Builder().build();
        this.mAdView.loadAd(build);
        this.mAdView.setAdListener(new AdListener() {
            public void onAdClosed() {
            }

            public void onAdLoaded() {
                super.onAdLoaded();
            }

            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                MainActivity.this.mAdView.loadAd(build);
            }

            public void onAdOpened() {
                super.onAdOpened();
            }

            public void onAdClicked() {
                super.onAdClicked();
            }
        });
    }
}
